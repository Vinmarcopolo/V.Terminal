# V.TERMINAL

A single-file markets and world-risk terminal: indices, sectors, retail vs institutional flows, world risk, crypto, news and a command line.

## Important: the data is a snapshot

All figures are hard-coded in `index.html` (search for `var DATA`) and dated to the Fri 16 Oct 2026 US close. Nothing on the page fetches live prices. The clocks and animations are real or decorative; no price ever moves.

The question box in the command line is powered by Claude's artifact runtime and only works when the page is opened inside claude.ai. On any other host it shows a short "not connected" message; the built-in commands (`help`, `idx`, `flows`, `risk`, ...) still work.

## Run locally

Open `index.html` in a browser. No build step, no dependencies. Fonts load from Google Fonts.

## Deploy

Vercel: import the repo, Framework Preset "Other", leave build and output settings empty. `vercel.json` is already set.

## Updating the data

Edit the `DATA` object in `index.html` and set `CLOSE_UTC` to the new close time. Keep sources linked.

Information only, not investment advice.
